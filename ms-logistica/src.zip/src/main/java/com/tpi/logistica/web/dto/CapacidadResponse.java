package com.tpi.logistica.web.dto;

public record CapacidadResponse(boolean valido) {}
